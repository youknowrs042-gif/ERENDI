<?php
/**
 * QR Code Generation - Using QR Server API (no JS dependency)
 * SIKAPDIK
 */
require_once __DIR__ . '/../../config/app.php';
Auth::requireRole(['admin']);

define('PAGE_TITLE', 'Generate QR Code');

$db = Database::getInstance();

// Handle QR regeneration
if (isPost() && Security::validateCSRF()) {
    $formAction = post('form_action');
    
    if ($formAction === 'generate_all') {
        $students = $db->fetchAll("SELECT id FROM students WHERE is_active = 1 AND (qr_token IS NULL OR qr_token = '')");
        $count = 0;
        foreach ($students as $s) {
            $token = Security::generateToken(32);
            $db->update('students', ['qr_token' => $token, 'qr_generated_at' => date('Y-m-d H:i:s')], 'id = ?', [$s['id']]);
            $count++;
        }
        Auth::logActivity('generate_qr_batch', 'qrcode', "Generate QR Code untuk {$count} siswa");
        setFlash('success', "QR Code berhasil digenerate untuk {$count} siswa.");
    } elseif ($formAction === 'regenerate') {
        $studentId = (int) post('student_id');
        $token = Security::generateToken(32);
        $db->update('students', ['qr_token' => $token, 'qr_generated_at' => date('Y-m-d H:i:s')], 'id = ?', [$studentId]);
        Auth::logActivity('regenerate_qr', 'qrcode', "Regenerate QR untuk siswa ID: {$studentId}");
        setFlash('success', 'QR Code berhasil digenerate ulang.');
    }
    redirect('modules/admin/qrcode.php');
}

$classFilter = get('class_id');
$classes = $db->fetchAll("SELECT id, class_name, grade_level FROM classes WHERE is_active = 1 ORDER BY grade_level, class_name");

$where = "s.is_active = 1";
$params = [];
if (!empty($classFilter)) {
    $where .= " AND s.class_id = ?";
    $params[] = $classFilter;
}
$students = $db->fetchAll("SELECT s.*, c.class_name, c.grade_level FROM students s LEFT JOIN classes c ON s.class_id = c.id WHERE {$where} ORDER BY c.grade_level, c.class_name, s.full_name", $params);

$noQrCount = $db->count('students', "is_active = 1 AND (qr_token IS NULL OR qr_token = '')");

include __DIR__ . '/../../templates/header.php';
?>

<style>
    /* Entrance Animation */
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .animate-fade-in {
        opacity: 0;
        animation: fadeInUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    }

    /* Staggered delay for cards */
    .stagger-1 { animation-delay: 0.1s; }
    .stagger-2 { animation-delay: 0.2s; }
    .stagger-3 { animation-delay: 0.3s; }
    
    /* Elegant Hover Effect for Cards */
    .qr-card-modern {
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        transform: translateY(0);
    }
    
    .qr-card-modern:hover {
        transform: translateY(-8px);
        box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        border-color: #6366f1; /* Indigo-500 */
    }

    /* QR Image Wrapper Styling */
    .qr-image-wrapper {
        background: linear-gradient(145deg, #ffffff, #f8fafc);
        box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.05);
        border: 1px solid #e2e8f0;
        position: relative;
    }

    /* Pulse animation for empty state */
    @keyframes softPulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.5; }
    }
    .animate-soft-pulse {
        animation: softPulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
    }

    /* Print Styles */
    @media print {
        .sidebar, aside, header, nav, .no-print { display: none !important; }
        body { background: white !important; }
        .flex.h-screen { display: block !important; }
        main { padding: 0 !important; margin: 0 !important; }
        .qr-card-modern { 
            break-inside: avoid; 
            page-break-inside: avoid; 
            border: 1px solid #ccc !important; 
            box-shadow: none !important; 
            transform: none !important;
            margin-bottom: 12px; 
        }
        .qr-image-wrapper { background: transparent !important; box-shadow: none !important; }
        #qrCards { display: grid !important; grid-template-columns: repeat(4, 1fr) !important; gap: 12px !important; }
        .qr-card-modern img { width: 120px !important; height: 120px !important; }
    }
</style>

<div class="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 mb-6 animate-fade-in">
    <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div class="flex items-center gap-4">
            <div class="w-12 h-12 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600">
                <i class="fas fa-qrcode text-2xl"></i>
            </div>
            <div>
                <h3 class="text-xl font-bold text-slate-800 tracking-tight">Manajemen QR Code</h3>
                <p class="text-sm mt-1">
                    <?php if ($noQrCount > 0): ?>
                    <span class="inline-flex items-center gap-1.5 py-1 px-2.5 rounded-full bg-orange-50 text-orange-600 font-medium border border-orange-100">
                        <span class="w-2 h-2 rounded-full bg-orange-500 animate-pulse"></span>
                        <?= $noQrCount ?> siswa belum memiliki QR Code
                    </span>
                    <?php else: ?>
                    <span class="inline-flex items-center gap-1.5 py-1 px-2.5 rounded-full bg-emerald-50 text-emerald-600 font-medium border border-emerald-100">
                        <i class="fas fa-check-circle"></i> Sistem Lengkap
                    </span>
                    <?php endif; ?>
                </p>
            </div>
        </div>
        
        <div class="flex flex-wrap gap-3">
            <?php if ($noQrCount > 0): ?>
            <form method="POST" onsubmit="return confirm('Generate QR untuk semua siswa yang belum memiliki?')" class="m-0">
                <?= Security::csrfField() ?>
                <input type="hidden" name="form_action" value="generate_all">
                <button type="submit" class="group inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-medium rounded-xl hover:from-emerald-600 hover:to-teal-700 shadow-md shadow-emerald-500/25 hover:shadow-emerald-500/40 transition-all duration-300">
                    <i class="fas fa-magic group-hover:rotate-12 transition-transform"></i> Generate Semua
                </button>
            </form>
            <?php endif; ?>
            <button type="button" onclick="window.print()" class="group inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-medium rounded-xl hover:from-indigo-600 hover:to-purple-700 shadow-md shadow-indigo-500/25 hover:shadow-indigo-500/40 transition-all duration-300">
                <i class="fas fa-print group-hover:-translate-y-0.5 transition-transform"></i> Cetak Dokumen
            </button>
        </div>
    </div>
</div>

<div class="bg-white/80 backdrop-blur-sm rounded-2xl shadow-sm border border-slate-100 p-5 mb-8 no-print animate-fade-in stagger-1">
    <form method="GET" class="flex flex-col sm:flex-row gap-3 items-end">
        <div class="flex-1 w-full">
            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Filter Kelas</label>
            <div class="relative">
                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <i class="fas fa-school text-slate-400"></i>
                </div>
                <select name="class_id" class="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all cursor-pointer hover:bg-white text-slate-700 font-medium">
                    <option value="">-- Tampilkan Semua Kelas --</option>
                    <?php foreach ($classes as $c): ?>
                    <option value="<?= $c['id'] ?>" <?= $classFilter == $c['id'] ? 'selected' : '' ?>>
                        Kelas <?= $c['grade_level'] ?> - <?= htmlspecialchars($c['class_name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <button type="submit" class="w-full sm:w-auto px-6 py-2.5 bg-slate-800 text-white font-medium rounded-xl hover:bg-slate-900 shadow-sm transition-colors flex items-center justify-center gap-2">
            <i class="fas fa-filter text-xs"></i> Terapkan
        </button>
    </form>
</div>

<div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-6" id="qrCards">
    <?php 
    $delayCounter = 2; // For stagger animation
    foreach ($students as $s): 
        $staggerClass = 'stagger-' . ($delayCounter > 3 ? 3 : $delayCounter); // Cap animation delay
        $delayCounter++;
    ?>
    <div class="bg-white rounded-2xl shadow-sm border border-slate-100 p-5 text-center qr-card-modern animate-fade-in <?= $staggerClass ?>">
        
        <div class="flex justify-end mb-2 no-print">
            <?php if ($s['qr_token']): ?>
                <span class="inline-flex items-center px-2 py-1 rounded-md bg-emerald-50 text-emerald-600 text-[10px] font-bold tracking-wider uppercase">
                    <i class="fas fa-check mr-1"></i> Aktif
                </span>
            <?php else: ?>
                <span class="inline-flex items-center px-2 py-1 rounded-md bg-orange-50 text-orange-600 text-[10px] font-bold tracking-wider uppercase">
                    <i class="fas fa-times mr-1"></i> Kosong
                </span>
            <?php endif; ?>
        </div>

        <div class="mb-5 relative">
            <?php if ($s['qr_token']): ?>
            <div class="qr-image-wrapper p-3 w-40 h-40 mx-auto rounded-2xl flex items-center justify-center group">
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=<?= urlencode($s['qr_token']) ?>&color=0f172a&bgcolor=ffffff&format=png&margin=0" 
                     alt="QR <?= htmlspecialchars($s['full_name']) ?>" 
                     class="w-full h-full object-contain rounded-lg mix-blend-multiply group-hover:scale-105 transition-transform duration-300"
                     loading="lazy">
            </div>
            <?php else: ?>
            <div class="w-40 h-40 mx-auto bg-slate-50 rounded-2xl flex items-center justify-center border-2 border-dashed border-slate-200 animate-soft-pulse">
                <div class="text-center">
                    <div class="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm mx-auto mb-2 text-slate-300">
                        <i class="fas fa-qrcode text-xl"></i>
                    </div>
                    <p class="text-xs text-slate-400 font-medium">Belum Ada QR</p>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
        <div class="space-y-1">
            <h4 class="font-bold text-slate-800 text-sm truncate px-2" title="<?= htmlspecialchars($s['full_name']) ?>">
                <?= htmlspecialchars($s['full_name']) ?>
            </h4>
            <div class="flex items-center justify-center gap-2 text-xs text-slate-500 font-medium">
                <span><?= $s['nis'] ?></span>
                <span class="w-1 h-1 rounded-full bg-slate-300"></span>
                <span class="text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md">
                    <?= $s['class_name'] ? $s['grade_level'] . ' - ' . $s['class_name'] : '-' ?>
                </span>
            </div>
        </div>
        
        <div class="mt-5 pt-4 border-t border-slate-50 no-print">
            <form method="POST" class="inline">
                <?= Security::csrfField() ?>
                <input type="hidden" name="form_action" value="regenerate">
                <input type="hidden" name="student_id" value="<?= $s['id'] ?>">
                <button type="submit" class="w-full inline-flex items-center justify-center gap-2 px-4 py-2 bg-slate-50 hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 text-xs font-semibold rounded-lg transition-colors group" onclick="return confirm('Anda yakin ingin membuat ulang (Regenerate) QR Code untuk <?= htmlspecialchars($s['full_name']) ?>?')">
                    <i class="fas fa-sync-alt group-hover:rotate-180 transition-transform duration-500"></i> Regenerate QR
                </button>
            </form>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<?php if (empty($students)): ?>
<div class="flex flex-col items-center justify-center py-16 bg-white rounded-2xl border border-slate-100 border-dashed animate-fade-in">
    <div class="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center mb-4 text-slate-300">
        <i class="fas fa-search text-3xl"></i>
    </div>
    <h3 class="text-lg font-bold text-slate-700">Data Tidak Ditemukan</h3>
    <p class="text-slate-500 text-sm mt-1">Belum ada data siswa untuk kelas yang dipilih.</p>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../../templates/footer.php'; ?>